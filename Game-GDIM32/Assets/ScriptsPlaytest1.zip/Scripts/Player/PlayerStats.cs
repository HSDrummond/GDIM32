using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayersStats : MonoBehaviour
{
    static public int p1_item_count;
    static public int p1_crop_count;
    static public int p1_animal_count;

    static public int p2_item_count;
    static public int p2_crop_count;
    static public int p2_animal_count;
}
