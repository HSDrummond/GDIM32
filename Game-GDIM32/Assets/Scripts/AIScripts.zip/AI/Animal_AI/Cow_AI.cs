using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Cow_AI : Animal
{
    void Start()
    {

    }
    //Array of stats
}
